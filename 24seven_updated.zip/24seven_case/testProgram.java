import java.time.LocalDate;
import model.Hotell;
import model.HotellkjedeModel;
import model.Kunde;

//sjekker om metodene i dataModel fungerer som ønsket. 
public class testProgram {
    public static void main(String[] args){
        HotellkjedeModel hk= new HotellkjedeModel("Mip");
        Hotell hotellOslo=new Hotell(3);

        hk.leggTilHotell(hotellOslo);
    
        hotellOslo.leggTilRom(103, 1, 2, "enkelt");
        hotellOslo.leggTilRom(205, 2, 1, "enkelt");
        hotellOslo.leggTilRom(305, 3, 1, "enkelt");
        hotellOslo.leggTilRom(201, 2, 2, "dobbelt");
        hotellOslo.leggTilRom(306, 3, 2, "dobbelt");

        Kunde kunde=new Kunde("Shanza", "inkognitoveien 33", 96826318);
        LocalDate innsjekkDato = LocalDate.of(2024, 11, 20);
        LocalDate utsjekkDato = LocalDate.of(2024, 11, 25);

        //reservasjoner med romtype angitt
        hotellOslo.reserverRom(innsjekkDato,utsjekkDato, "enkelt", kunde, 0);
        hotellOslo.reserverRom(innsjekkDato,utsjekkDato, "enkelt", kunde, 0);
        hotellOslo.reserverRom(innsjekkDato,utsjekkDato, "enkelt", kunde, 0);
        hotellOslo.reserverRom(innsjekkDato,utsjekkDato, "enkelt", kunde, 0); //ingen ledige enkeltrom

        hotellOslo.reserverRom(innsjekkDato,utsjekkDato, "dobbelt", kunde, 0);
        


        //reservasjoner for spesifikke rom
        hotellOslo.reserverSpesifiktRom(innsjekkDato, utsjekkDato, 306, kunde, 0); //spesifikt rom reservert
        hotellOslo.reserverSpesifiktRom(innsjekkDato, utsjekkDato, 306, kunde, 0); //ikke ledig
    }
    
}
