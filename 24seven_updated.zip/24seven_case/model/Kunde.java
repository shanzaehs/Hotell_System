package model;
public class Kunde extends Person {
    private int lojalitetspoeng=0;

    public Kunde(String navn, String adresse, int telefonnummer){
        super(navn, adresse, telefonnummer);
    }
    
    @Override
    public void visDetaljer(){
        System.out.println("Kunde: " + navn+ "\n" + "telefon: " + telefonNr);
    }

    //øker poeng for hver gang kunden gjør en reservasjon
    public void leggTilPoeng(){
        lojalitetspoeng++;
    }

    public int hentPoeng(){
        return lojalitetspoeng;
    }
    //Bør ha egen metode for å reservere rom
}
