package model;
public class EnkeltRom extends Rom{
    public EnkeltRom (int nr, int etasje, int antSeng) {
        super(nr, etasje, antSeng);
        }
}
