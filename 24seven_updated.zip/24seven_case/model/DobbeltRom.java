package model;
public class DobbeltRom extends Rom {
    public DobbeltRom (int nr, int etasje, int antSeng) {
        super(nr, etasje, antSeng);
        }
}
