package model;
public class Ansatt extends Person{
    String stilling;
    private static int idTeller=1; //statisk teller for å holde styr på ansatte
    public final int ansattId;
    //bør ha instans av hotellet hen jobber på?

    public Ansatt(String navn, String adresse, int telefonnummer, int lojalitetPoeng, String stilng){
        super(navn, adresse, telefonnummer);
        stilling=stilng;
        ansattId=idTeller++;

    }
    
    @Override
    public void visDetaljer(){
        System.out.println("Ansatt: " + navn+ "\n" + "Stilling: " + stilling + "\n" + "telefon: " + telefonNr);
    }

    public void seHistorikk(){
        //logikk for å se historikk fra rom/reservasjoner
        //rom.hentHistorikk f.eks. 
    }
}
