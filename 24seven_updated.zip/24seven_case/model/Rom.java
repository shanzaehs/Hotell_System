package model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class Rom { //kan utvides til andre romtyper, eks. suites etc. 

    final int etasje, ant_sengeplasser;
    public int romnr = 0;
    List<Reservasjon> reservasjoner = new ArrayList<Reservasjon>(); //liste over rommets reservasjoner

    
    Rom (int nr, int etg, int antSeng) {
	romnr = nr;  //antatt at romnr ikke kan være 0
	etasje = etg; 
    ant_sengeplasser = antSeng;
    }

    // Sjekker om rommet er ledig for en gitt periode
    public boolean erLedig(LocalDate innsjekking, LocalDate utsjekking) {
        for (Reservasjon reservasjon : reservasjoner) {
            if (reservasjon.overlapp(innsjekking, utsjekking)) {
                return false;
            }
        }
        return true;
    }

    public void leggTilReservasjon(Reservasjon res){
        reservasjoner.add(res);
    }

    //sjekker om rommet er enkeltrom
    public boolean erEnkeltRom() {
        return this instanceof EnkeltRom;
    }

    // Sjekker om rommet er et DobbeltRom
    public boolean erDobbeltRom() {
        return this instanceof DobbeltRom;
    }

    public void hentHistorikk(){
        //historikken for dette rommet
    }
}
