package model;
import java.util.ArrayList;
import java.time.LocalDate;

public class HotellkjedeModel {
    String hotellkjede;
    ArrayList<Hotell> hoteller= new ArrayList<Hotell>(); //dynamisk liste som har orden på hotellene i kjeden

    Kunde kunde=new Kunde("Shanza", "Problemveien 11", 96835491); //for tests skyld
    //bør ha logikk for autentisering av bruker- er du ansatt eller kunde?

    public HotellkjedeModel(String navn){
        hotellkjede=navn;
    }

    //kan brukes av adminstrator
    public void leggTilHotell(Hotell hotell){
        hoteller.add(hotell);
    }

    public void fjernHotell(Hotell hotell){

        if(hoteller.contains(hotell)){ //om hotellet er i hotellkjeden, kunne også sjekket på navn
            hoteller.remove(hotell);
        }
        return;
        
    }

    public void reserverRom(int hotellId, LocalDate innsjekk, LocalDate utsjekk, String romtype, int romnr){
        //antar at reservasjonen gjøres av kunden
        Hotell hotell=null;

        //finner gjeldende hotell
        for(Hotell h:hoteller){
            if(h.hotellId==hotellId){
                hotell=h;
            }else{
                return; 
            }
        }

        if(!romtype.equals(" ")){
            hotell.reserverRom(innsjekk, utsjekk, romtype, kunde, 0); 
            return;
        }

        //siden romtype ikke var angitt, må bruker ha oppgitt spesifikt nummer

        hotell.reserverSpesifiktRom(innsjekk, utsjekk, romnr, kunde, 0);

        //kan returnere true eller false om rom ble reservert, og deretter skrive meld til bruker
        //legg til status textfield på viewet, samt en "søk"-knapp

    }
}
