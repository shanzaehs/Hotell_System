package view;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import controller.HotellKontroller;

public class HotellView {
    JFrame vindu;
    JPanel hovedPanel;
    JPanel toppPanel;
    JPanel datoerPanel;
    JPanel romtypePanel;
    JLabel valg1;
    JLabel innsjekk;
    JLabel utsjekk;
    JLabel romtype;
    JTextField innsjekkTekst;
    JTextField utsjekkTekst;
    JTextField romnr;
    JButton hotellOsloKnapp;
    JButton hotellBerlinKnapp;
    JButton enkeltRomKnapp;
    JButton dobbeltRomKnapp;
    private JLabel statusMelding; 

    //legg til "status" textfield på viewet, samt en "søk"-knapp som bruker kan trykke på etter å gjort sine valg. 

    public HotellView(HotellKontroller k) {
        HotellKontroller kontroll = k;

        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.exit(9);
        }

        // Oppretter vinduet
        vindu = new JFrame("Hotell Booking");
        vindu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vindu.setSize(600, 400);

        // Lager hovedpanelet
        hovedPanel = new JPanel();
        hovedPanel.setLayout(new BorderLayout());  // Bruker BorderLayout for hovedpanelet

        leggTilHotellValg();
        leggTilDatoer();
        leggTilRomtype();

        // Kompilerer og gjør vinduet synlig
        vindu.add(hovedPanel);
        vindu.pack();
        vindu.setLocationRelativeTo(null); // Plasserer vinduet i midten
        vindu.setVisible(true);
    }

    public void leggTilHotellValg() {
        toppPanel = new JPanel();
        toppPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); // For å arrangere elementene på en horisontal linje

        Font tekstFont = new Font("Arial", Font.PLAIN, 20);
        valg1 = new JLabel("Velg hotell: ");
        valg1.setFont(tekstFont);
        toppPanel.add(valg1);

        hotellOsloKnapp = new JButton("Hotell Oslo");
        hotellOsloKnapp.setFont(tekstFont);
        hotellOsloKnapp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handling for Hotell Oslo, kontroller
               // kontroll.reserverRomFraView(1);
                
            }
        });
        toppPanel.add(hotellOsloKnapp);

        hotellBerlinKnapp = new JButton("Hotell Berlin");
        hotellBerlinKnapp.setFont(tekstFont);
        hotellBerlinKnapp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handling for Hotell Berlin, kontroller
                //kun for utvidelses skyld
            }
        });
        toppPanel.add(hotellBerlinKnapp);

        hovedPanel.add(toppPanel, BorderLayout.NORTH);  // Plasserer i toppen
    }

    public void leggTilDatoer() {
        datoerPanel = new JPanel();
        datoerPanel.setLayout(new GridLayout(2, 2, 10, 10));  // 2 rader og 2 kolonner

        Font tekstFont = new Font("Arial", Font.PLAIN, 20);

        innsjekk = new JLabel("Innsjekkingsdato (yyy-mm-dd): ");
        innsjekk.setFont(tekstFont);
        datoerPanel.add(innsjekk);

        innsjekkTekst = new JTextField();
        innsjekkTekst.setFont(tekstFont);
        datoerPanel.add(innsjekkTekst);

        utsjekk = new JLabel("Utsjekkingsdato: ");
        utsjekk.setFont(tekstFont);
        datoerPanel.add(utsjekk);

        utsjekkTekst = new JTextField();
        utsjekkTekst.setFont(tekstFont);
        datoerPanel.add(utsjekkTekst);

        hovedPanel.add(datoerPanel, BorderLayout.CENTER);  // Plasserer i midten 
    }

    public void leggTilRomtype() {
        romtypePanel = new JPanel();
        romtypePanel.setLayout(new FlowLayout(FlowLayout.LEFT));  // Horisontalt arrangert

        Font tekstFont = new Font("Arial", Font.PLAIN, 20);

        romtype = new JLabel("Velg romtype eller romnr.: ");
        romtype.setFont(tekstFont);
        romtypePanel.add(romtype);

        // Knappene for romtyper
        enkeltRomKnapp = new JButton("Enkelt rom");
        enkeltRomKnapp.setFont(tekstFont);
        romtypePanel.add(enkeltRomKnapp);

        dobbeltRomKnapp = new JButton("Dobbelt rom");
        dobbeltRomKnapp.setFont(tekstFont);
        romtypePanel.add(dobbeltRomKnapp);

        // Romnummerfeltet, NB: blir lite, må fikse size
        romnr = new JTextField();
        romnr.setFont(tekstFont);
        romtypePanel.add(romnr);

        // ActionListener for romtypeknappene
        enkeltRomKnapp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handling for enkelt rom m kontroller
            }
        });

        dobbeltRomKnapp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handling for dobbelt m kontroller
            }
        });

        hovedPanel.add(romtypePanel, BorderLayout.SOUTH);  // Plasserer i bunnen 
    }

     // Metoder som lar kontroller hente brukerinput
     public String getInnsjekkDato() {
        return innsjekkTekst.getText();
    }

    public String getUtsjekkDato() {
        return utsjekkTekst.getText();
    }

    public String getRomNrValg() {
        return romnr.getText();
    }

    // Statusmelding som kontroller kan sette
    public void visStatusMelding(String melding) {
        statusMelding.setText(melding);
    }

}
