package controller;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import model.HotellkjedeModel;
import view.HotellView;

public class HotellKontroller {
    private HotellkjedeModel model;
    private HotellView view;


    public void start(){
       model=new HotellkjedeModel("Min hotellkjede");
       view= new HotellView(this); //sender inn seg selv

    }

    //ikke fullført: mangler logikk for romtype etc. , men gir en ide
    public void reserverRomFraView(int hotellId) {
        try {
            LocalDate innsjekk = LocalDate.parse(view.getInnsjekkDato());
            LocalDate utsjekk = LocalDate.parse(view.getUtsjekkDato());
            String romNrTekst = view.getRomNrValg();
            int romnr = romNrTekst.isEmpty() ? 0 : Integer.parseInt(romNrTekst); //parser til int
            
            model.reserverRom(hotellId, innsjekk, utsjekk, "", romnr);

            view.visStatusMelding("Reservasjon vellykket!");

        } catch (DateTimeParseException e) {
            view.visStatusMelding("Ugyldig datoformat. Bruk yyyy-mm-dd.");
        } catch (NumberFormatException e) {
            view.visStatusMelding("Ugyldig romnummer.");
        } catch (Exception e) {
            view.visStatusMelding("Feil under reservasjon: " + e.getMessage());
        }
    }
}
