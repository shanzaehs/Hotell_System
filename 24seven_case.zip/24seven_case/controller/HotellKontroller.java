package controller;
import model.HotellkjedeModel;
import view.HotellView;

public class HotellKontroller {
    private HotellkjedeModel model;
    private HotellView view;


    public void start(){
       model=new HotellkjedeModel("Min hotellkjede");
       view= new HotellView(this); //sender inn seg selv

       //programmets logikk skal gå her, kobler model og view slik at funksjonalitet fungerer.
    }
}
