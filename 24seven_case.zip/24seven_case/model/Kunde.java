package model;
public class Kunde extends Person {
    int lojalitetspoeng;

    public Kunde(String navn, String adresse, int telefonnummer, int lojalitetPoeng){
        super(navn, adresse, telefonnummer);


    }
    
    @Override
    public void visDetaljer(){
        System.out.println("Kunde: " + navn+ "\n" + "telefon: " + telefonNr);
    }
}
