package model;
import java.time.LocalDate;
import java.util.ArrayList;


public class Hotell {
    private static int idteller=1; //statisk teller for å holde styr på hotell-ider
    public final int hotellId;
    int etasjer;
    ArrayList<Rom> hotellrom=new ArrayList<Rom>();

    public Hotell(int etasjer){
        this.etasjer=etasjer;
        hotellId=idteller++; //øker for hvert hotell-objekt som lages
    }

    public void leggTilRom(int nr, int etasje, int senger, String romtype){ 
        //antatt at romtype angis, og er gyldig
        Rom rom;
        if(romtype.equals("enkelt")){
            rom=new EnkeltRom(nr, etasje, senger);
        }else{
            rom=new DobbeltRom(nr, etasje, senger);
        }
        
        hotellrom.add(rom);
    }

    public void reserverSpesifiktRom(LocalDate innsjekk, LocalDate utsjekk, int nr, Kunde kunde, int ansattId){
        if(nr!=0){
            for(Rom rom:hotellrom){
                if(rom.romnr==nr && rom.erLedig(innsjekk, utsjekk)){
                    Reservasjon res=new Reservasjon(rom, kunde, innsjekk, utsjekk);
                    rom.leggTilReservasjon(res);
                    System.out.println("Et enkeltrom er reservert.");
                }
            }
        }
        
    }

    public void reserverRom(LocalDate innsjekk, LocalDate utsjekk, String romtype, Kunde kunde, int ansattId){
        Reservasjon res=null;
        boolean reservert=false;

        //antar at listen ikke er tom (NP exception) (input-validering bør implementres)
        for (Rom rom:hotellrom){
            if(rom.erLedig(innsjekk, utsjekk)){

                if(romtype.equals("enkelt")&& rom.erEnkeltRom()){
                    res=new Reservasjon(rom, kunde, innsjekk, utsjekk);
                    rom.leggTilReservasjon(res);
                    System.out.println("Et enkeltrom er reservert.");
                    reservert=true;
                    break; //avslutter loopen
                }
                else if(romtype.equals("dobbelt")&& rom.erDobbeltRom()){
                    res=new Reservasjon(rom, kunde, innsjekk, utsjekk);
                    rom.leggTilReservasjon(res);
                    System.out.println("Et dobbeltrom er reservert.");
                    reservert=true;
                    break;
                }
            }
        }

       if(!reservert){
            System.out.println("Ingen ledige rom av typen: " + romtype);
        }

        //må sette logikk for ansatt-booking
    }
}
