package model;
import java.util.ArrayList;

public class HotellkjedeModel {
    String hotellkjede;
    ArrayList<Hotell> hoteller= new ArrayList<Hotell>(); //dynamisk liste som har orden på hotellene i kjeden

    public HotellkjedeModel(String navn){
        hotellkjede=navn;
    }

    public void leggTilHotell(Hotell hotell){
        hoteller.add(hotell);
    }

    public void fjernHotell(Hotell hotell){

        if(hoteller.contains(hotell)){ //om hotellet er i hotellkjeden, kunne også sjekket på navn
            hoteller.remove(hotell);
        }
        return;
        
    }
}
