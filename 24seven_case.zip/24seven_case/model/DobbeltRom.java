package model;
public class DobbeltRom extends Rom {
    DobbeltRom (int nr, int etasje, int antSeng) {
        super(nr, etasje, antSeng);
        }
}
