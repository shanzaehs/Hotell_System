package model;
public abstract class Person {
    String navn;
    String adresse;
    int telefonNr; //unik identifikator (med landskode)

    public Person(String n, String adr, int tlfnr){
        navn=n;
        adresse=adr;
        telefonNr=tlfnr;
    }

    public abstract void visDetaljer(); //kan implementeres av subklassene kunde og Ansatt

}
