package model;
public class EnkeltRom extends Rom{
    EnkeltRom (int nr, int etasje, int antSeng) {
        super(nr, etasje, antSeng);
        }
}
