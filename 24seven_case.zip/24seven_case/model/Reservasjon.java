package model;
import java.time.LocalDate;

public class Reservasjon { 
    private Rom valgt;
    private Kunde kunde;
    private int ansatt = 0; //dersom en ansatt lagde bookingen for kunden har vi ansattId
    private LocalDate innsjekking;
    private LocalDate utsjekking;
    
    public Reservasjon(Rom rom, Kunde k, LocalDate inn, LocalDate ut){
        valgt=rom;
        innsjekking=inn;
        utsjekking=ut;
        kunde=k;
        
    }

    //dersom en ansatt lagde bookingen og man vil ha med ansatten
    public Reservasjon(Rom rom, Kunde k, LocalDate inn, LocalDate ut, int ansattId){
        valgt=rom;
        innsjekking=inn;
        utsjekking=ut;
        kunde=k;
        ansatt=ansattId;
    }


    public LocalDate hentInnsjekking(){
        return innsjekking;
    }

    public LocalDate hentUtsjekking(){
        return utsjekking;
    }

    public boolean overlapp(LocalDate innsjekking, LocalDate utsjekking) {
        
        boolean utsjekkingForInnsjekking = utsjekking.isBefore(this.innsjekking);
        boolean innsjekkingEtterUtsjekking = innsjekking.isAfter(this.utsjekking);

        if (utsjekkingForInnsjekking || innsjekkingEtterUtsjekking) {
            return false; //overlapper ikke
        }

        // Hvis ingen av de ovennevnte betingelsene er sanne, overlapper periodene.
        return true;
    }
}
