import view.HotellView;
import controller.HotellKontroller;;

public class hovedprogram {
    public static void main(String[] args){
        HotellKontroller kontroller=new HotellKontroller();
        kontroller.start(); //oppretter objektene model, view
    }
}
